<?php 

namespace App\Models;

use Codeigneter\Model;
use CodeIgniter\Model as CodeIgniterModel;

class Mregistrasi extends Model {
    protected $table ='member';
    protected $allowedFields = ['nama', 'email', 'password']
}
